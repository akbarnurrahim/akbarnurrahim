<?php

class Login extends CI_Controller
{

    function index()
    {
        $this->load->view('Tampilan_login');
        
    }
    
    function getlogin()
    {
        $pin = $this->input->post('pin');
        $this->load->model('model_login');
        $this->model_login->getlogin($pin);
    }
}
?>
