<?php

class Metode extends CI_Controller
{
    public function index()
    {
        return $this->fcfs();
    }
    
    public function fcfs()
    {
        $data['judul'] = 'Metode First Come First Served';
        $data['subjudul'] = 'fcfs';
        $data['simpan'] = 'simpanfcfs';
        $data['next'] = 'sjf';
        $data['warna'] = 'purple';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_metode',$data);
    }
    
  
    
    public function sjf()
    {
        $data['judul'] = 'Metode Short Job First';
        $data['subjudul'] = 'sjf';
        $data['simpan'] = 'simpansjf';
        $data['next'] = 'sjfnp';
        $data['warna'] = 'blue';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_metode',$data);
    }
    
    public function sjfnp()
    {
        $data['judul'] = 'Metode Short Job First Non Preemptive';
        $data['subjudul'] = 'sjfnp';
        $data['simpan'] = 'simpansjfnp';
        $data['next'] = 'priority';
        $data['warna'] = 'red';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_metode',$data);
    }
    
    public function priority()
    {
        $data['judul'] = 'Metode Priority';
        $data['subjudul'] = 'priority';
        $data['simpan'] = 'simpanpriority';
        $data['next'] = 'prioritynp';
        $data['warna'] = 'navy';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_khususpriority',$data);
    }
    
    public function prioritynp()
    {
        $data['judul'] = 'Metode Priority Non Preemptiv';
        $data['subjudul'] = 'prioritynp';
        $data['simpan'] = 'simpanprioritynp';
        $data['next'] = 'roundrobin';
        $data['warna'] = 'green';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_khususpriority',$data);
    }
    
    public function roundrobin()
    {
        $data['judul'] = 'Metode Round Robin';
        $data['subjudul'] = 'roundrobin';
        $data['simpan'] = 'simpanroundrobin';
        $data['next'] = 'fcfs';
        $data['warna'] = 'black';
        $this->Model_autologout->autologout();
        $this->load->view('Tampilan_metode',$data);
    }
}
?>
