<?php

class Proses extends CI_Controller
{
    
    
    public function simpanfcfs()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedata',$proses[$i]);
         }
           redirect('tampil/fcfs');
    }
    
    public function simpansjf()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedata',$proses[$i]);
         }
           redirect('tampil/sjf');
    }
    
    
    public function simpansjfnp()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedata',$proses[$i]);
         }
           redirect('tampil/sjfnp');
    }
    
    public function simpanpriority()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedatapriority',$proses[$i]);
         }
           redirect('tampil/priority');
    }
    
    public function simpanprioritynp()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedatapriority',$proses[$i]);
         }
           redirect('tampil/prioritynp');
    }
    
    public function simpanroundrobin()
    {
        $jumlah = $this->input->post("jumlah");
        
        for ($i=1; $i<=$jumlah; $i++)
        {
        $proses[$i] = array (
                    'nmproses' => $this->input->post("proses".$i),
                    'at' => $this->input->post("at".$i),
                    'bt' => $this->input->post("bt".$i)
                );     
               
         $this->db->insert('metodedata',$proses[$i]);
         }
           redirect('tampil/roundrobin');
    }
    

        
        
  

            
          
    }
        

    


  
?>
