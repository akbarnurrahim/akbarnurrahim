<?php

class Tampil extends CI_Controller 
{
     public function fcfs()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'red';
           $data['subjudul'] = 'fcfs';
           $data['judul'] = 'Hasil Metode First Come First Served';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan Arrival Time Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatafcfs();
           $this->load->view('tampilan_hasil',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deleteotomatis();
   
   }
   
   public function sjf()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'blue';
           $data['subjudul'] = 'sjf';
           $data['judul'] = 'Hasil Metode Shortest-Job First ';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan <b>Burst Time </b> Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatasjf();
           $this->load->view('tampilan_hasil',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deleteotomatis();
   }
   
     public function sjfnp()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'blue';
           $data['subjudul'] = 'sjfnp';
           $data['judul'] = 'Hasil Metode Shortest-Job First Non Preemptive';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan <b>Burst Time </b> Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatasjfnp();
           $this->load->view('tampilan_hasil',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deleteotomatis();
    }
    
    public function priority()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'blue';
           $data['subjudul'] = 'priority';
           $data['judul'] = 'Hasil Metode Priority';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan <b>Priority </b> Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatapriority();
           $this->load->view('tampilan_hasilpriority',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deletepriority();
    }
    
    public function prioritynp()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'blue';
           $data['subjudul'] = 'sjf';
           $data['judul'] = 'Hasil Metode Priority Non Preemptive';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan <b>Priority </b> Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatapriority();
           $this->load->view('tampilan_hasilpriority',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deletepriority();
    }
    
     public function roundrobin()
     {
           $jumlah = $this->input->post('jumlah');
           $data['warna'] = 'blue';
           $data['subjudul'] = 'sjf';
           $data['judul'] = 'Hasil Metode Round Robin';
           $data['total'] = $jumlah;
           $data['peringatan'] = '*Diurutkan Berdasarkan <b>Arrival Time </b> Tercepat';
           
           $data['hasil'] = $this->Model_data->tampildatapriority();
           $this->load->view('tampilan_hasil',$data);
          
           // -------- Hapus Seluruh Data Dalam Tabel Jika Data Sudah Di Tampilkan
           $this->load->model('model_data');
           $this->model_data->deleteotomatis();
    }
        
        
}
?>
