<?php

class Model_autologout extends CI_Model
{
    public function autologout()
    {
        $pin = $this->session->userdata('pin');
        if (empty($pin))
        {
            $this->session->sess_destroy();
            redirect('login');
            
        }
    }
    
    public function autobalik()
    {
        $aktivitas = $this->session->userdata('aktivitas');
        if (empty($aktivitas))
        {
            redirect('metode');
            
        }
    }
    
 
}
?>
