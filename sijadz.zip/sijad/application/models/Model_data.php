<?php

class Model_data extends CI_Model
{
    
    function tampildatafcfs()
    {
        $this->db->order_by('at', 'ASC');
        $hasil = $this->db->get('metodedata');
        return $hasil;
    }
    
    function tampildatasjf()
    {
        $this->db->order_by('bt', 'ASC');
        $hasil = $this->db->get('metodedata');
        return $hasil;
    }
    
     function tampildatasjfnp()
    {
        $this->db->order_by('bt', 'ASC');
        $hasil = $this->db->get('metodedata');
        return $hasil;
    }
    
     function tampildatapriority()
    {
        $this->db->order_by('priority', 'ASC');
        $hasil = $this->db->get('metodedatapriority');
        return $hasil;
    }
    
    function deleteotomatis()
    {
        $hapusquery = $this->db->query('DELETE FROM metodedata WHERE idproses != 08997018065;');
        return $hapusquery;
    }
    
    function deletepriority()
    {
        $hapusquery = $this->db->query('DELETE FROM metodedatapriority WHERE idproses != 08997018065;');
        return $hapusquery;
    }
     
 
}

?>
