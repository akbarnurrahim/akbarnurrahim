<?php

class Model_login extends CI_model 
{
    
    public function getlogin($pin)
    {
        $this->db->where('pin',$pin);
        $query = $this->db->get('auth');
        
        if ($query->num_rows()>0)
        {
            foreach ($query->result() as $row)
            {
                $sess = array('pin'     => $row->pin);
                $this->session->set_userdata($sess);
                redirect('home');
            }
            
        }
        else
        {
            $this->session->set_flashdata('info','Mohon Maaf Pin Yang Anda Masukan Tidak Cocok ! ');
            redirect('login');
        }
    } 


}
?>
