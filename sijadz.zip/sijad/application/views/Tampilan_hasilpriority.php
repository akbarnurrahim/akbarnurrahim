<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sistem Operasi | SAP.</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url();?>/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/skins/_all-skins.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/plugins/datatables/dataTables.bootstrap.css">


</head>

<script language="JavaScript" type="text/JavaScript">
counter = 0;
proses  = 0;
bt  = 0;
at  = 0;
jumlah = 0;

function action()
{
counterNext = counter + 1;
document.getElementById("nomber"+counter).innerHTML = "<input type='text' class='form-control'  value='"+counterNext+ ".' name='data[]' disabled><p id=\"nomber"+counterNext+"\"></p>";
counter++;

prosesNext = proses + 1;
document.getElementById("inputproses"+proses).innerHTML ="<input type='text' method='post' class='form-control' id='proses' placeholder='Masukan Nama Proses' name='proses"+prosesNext+  "'><p id=\"inputproses"+prosesNext+"\"></p>";
proses++;

btNext = bt + 1;
document.getElementById("inputbt"+bt).innerHTML ="<input type='text' method='post' class='form-control' placeholder='Masukan Jumlah BT' name='bt"+btNext+ "'><div id=\"inputbt"+btNext+"\"></p>";
bt++;

atNext = at + 1;
document.getElementById("inputat"+at).innerHTML ="<input type='text' method='post' class='form-control' placeholder='Masukan Jumlah AT' name='at"+atNext+ "'><p id=\"inputat"+atNext+"\"></p>";
at++;

jumlahNext = jumlah + 1;
document.getElementById("inputjumlah"+jumlah).innerHTML ="<input type='hidden' method='post' class='form-control' value='"+jumlahNext+ "' name='jumlah'><p id=\"inputjumlah"+jumlahNext+"\"></p>";
jumlah++;


}


</script>



<body class="hold-transition skin-purple-light layout-boxed sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <a href="../../index2.html" class="logo">
      <span class="logo-mini " >SAP<b>.</b></span>
      <span class="logo-lg"><i class="fa fa-code"></i><b>  SO </b>| SAP.</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-gears"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="<?php echo base_url(); ?>home/logout">Keluar</a></li>
              </ul>
            
         
        </ul>
      </div>
    </nav>
  </header>

  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li class="header"><center><b class="text-purple"> -Menu Utama-</b></center></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-align-justify"></i> <span> Sistem Operasi | SAP.</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>home"><i class="fa fa-home text-red"></i> Home </a></li>
            <li><a href="<?php echo base_url(); ?>home/#anggota"><i class="fa fa-user text-aqua"></i> Anggota Kelompok </a></li>
            <li><a href="<?php echo base_url(); ?>home/#aboutprogram"><i class="fa fa-code text-navy"></i> Tentang Program </a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa  fa-slack"></i> <span > Metode Algoritma</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>metode/fcfs"><i class="fa  fa-chevron-circle-right  text-red"></i> FCFS </a></li>
            <li><a href="<?php echo base_url(); ?>metode/sjf"><i class="fa  fa-chevron-circle-right  text-green"></i> SFJ </a></li>
            <li><a href="<?php echo base_url(); ?>metode/sjfnp"><i class="fa  fa-chevron-circle-right  text-blue"></i> SFJ-NP</a></li>
             <li><a href="<?php echo base_url(); ?>metode/priority"><i class="fa  fa-chevron-circle-right  text-lime"></i> PRIORITY</a></li>
              <li><a href="<?php echo base_url(); ?>metode/prioritynp"><i class="fa  fa-chevron-circle-right  text-olive"></i> PRIORITY-NP</a></li>
               <li><a href="<?php echo base_url(); ?>metode/roundrobin"><i class="fa  fa-chevron-circle-right  text-light-blue"></i> ROUND ROBIN</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i> <span>Documentations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>home"><i class="fa fa-github text-red"></i> Code On Github </a></li>
          </ul>
        </li>
        
    </section>

  </aside>

  <div class="content-wrapper">
    <section class="content-header">
        <small>* Beta Version (Non Database) </small>
      </h1>
      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-slack"></i> Metode Algoritma</a></li>
        <li><a href="#"><?php echo $subjudul ?></a></li>
      </ol>
    </section>
    <section class="content">

      <div class="box box-header ">
        <div class="box-header with-border">
          <h3 class="box-title text-<?php echo $warna ?>"><i class="fa  fa-slack t" ></i><?php echo $judul ?> </center></h3><br><br>
          <i class="fa fa-clock-o text-maroon"></i><small class="text-maroon"><?php echo $peringatan ?></small>
          <div class="box-tools pull-left">
            <button type="button" class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-minus"></i></button>
            <button type="button" class="btn btn-box-tool" data-widget="remove"><i class="fa fa-remove"></i></button>
          </div>
        </div>
         <form name="prosesalgoritma" action="<?php echo base_url();?>proses/<?php echo $subjudul ?>" method="post">
        <div class="box-body">
          <div class="row">
            <div class="col-md-8">
                 <table class="table table-striped" >
                <tr>
                    <thead>
                  <th style="width: 50px">No</th>
                  <th >Nama Proses</th>
                  <th>Burst Time (BT) </th>
                  <th>Arrival Time (AT) </th>
                  <th>Waiting Time (AT) </th>
                  <th>Priority </th>
                 </thead>
                </tr>
                <?php
                $no = 1;
                foreach ($hasil->result() as $row)
                {
                 ?>
                 <tr>
                 <tbody>
                 <td><b> <?php echo $no++; ?> </b></td>
                  <td><center><b><i><?php echo $row->nmproses ?></center></i></b></td>
                  <td><center><span class="badge bg-maroon"><?php echo  $row->bt ?><sub>ms</sub></span</center></td>
                  <td><center><span class="badge bg-green"><?php echo $row->at ?><sub>ms</sub></span></center></td>
                  <td><center><span class="badge bg-green"><?php echo $row->at ?><sub>ms</sub></span></center></td>
                  <td><center><span class="badge bg-green"><?php echo $row->at - $row->at + $row->bt ?><sub>ms</sub></span></center></td>
                </tr>
<?php  } 
?>
                  
                 </tbody>
              </table>  
            </div>
              <br>
              <div class="col-md-3">
                 <table class="table table-bordered">
                <tr>
                  <th class="bg-purple">Average Waiting Time (AWT)</th>
                </tr>
                
                <tr>
                  <td class="bg-gray">18 + 11 + = 24,5 MS</td>
                </tr>
              </table>
            </div> 
              
              
   
         </form>
      </div>
    </section>
  </div>

  <footer class="main-footer">
    <div class="pull-right hidden-xs text-purple" >
      Page rendered in <strong>{elapsed_time}</strong> Second.
    </div>
  </footer>

  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo base_url(); ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/datatables/dataTables.bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/datatables/jquery.dataTables.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/fastclick/fastclick.js"></script>
<script src="<?php echo base_url(); ?>/dist/js/app.min.js"></script>
<script src="<?php echo base_url(); ?>/dist/js/demo.js"></script>


</script>
</body>
</html>
