<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Sistem Operasi | SAP.</title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url();?>/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/AdminLTE.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/skins/_all-skins.min.css">


</head>

<script language="JavaScript" type="text/JavaScript">
counter = 0;
proses  = 0;
bt  = 0;
at  = 0;
jumlah = 0;

function action()
{
counterNext = counter + 1;
document.getElementById("nomber"+counter).innerHTML = "<input type='text' class='form-control'  value='"+counterNext+ ".' name='data[]' disabled><p id=\"nomber"+counterNext+"\"></p>";
counter++;

prosesNext = proses + 1;
document.getElementById("inputproses"+proses).innerHTML ="<input type='text' method='post' class='form-control' placeholder='Masukan Nama Proses' name='proses"+prosesNext+  "'><p id=\"inputproses"+prosesNext+"\"></p>";
proses++;

btNext = bt + 1;
document.getElementById("inputbt"+bt).innerHTML ="<input type='text' method='post' class='form-control' placeholder='Masukan Jumlah BT' name='bt"+btNext+ "'><div id=\"inputbt"+btNext+"\"></p>";
bt++;

atNext = at + 1;
document.getElementById("inputat"+at).innerHTML ="<input type='text' method='post' class='form-control' placeholder='Masukan Jumlah AT' name='at"+atNext+ "'><p id=\"inputat"+atNext+"\"></p>";
at++;

jumlahNext = jumlah + 1;
document.getElementById("inputjumlah"+jumlah).innerHTML ="<input type='hidden' method='post' class='form-control' value='"+jumlahNext+ "' name='jumlah'><p id=\"inputjumlah"+jumlahNext+"\"></p>";
jumlah++;

}


</script>

<body class="hold-transition skin-purple-light layout-boxed sidebar-mini">
<div class="wrapper">

  <header class="main-header">
    <a href="#" class="logo">
      <span class="logo-mini " >SAP<b>.</b></span>
      <span class="logo-lg"><i class="fa fa-code"></i><b>  SO </b>| SAP.</span>
    </a>
    <nav class="navbar navbar-static-top">
      <a href="#" class="sidebar-toggle" data-toggle="offcanvas" role="button">
        <span class="sr-only">Toggle navigation</span>
      </a>

      <div class="navbar-custom-menu">
        <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown"><i class="fa fa-gears"></i></a>
              <ul class="dropdown-menu" role="menu">
                <li><a href="<?php echo base_url(); ?>home/logout">Keluar</a></li>
              </ul>
            
         
        </ul>
      </div>
    </nav>
  </header>

  <aside class="main-sidebar">
    <section class="sidebar">
      <ul class="sidebar-menu">
        <li class="header"><center><b class="text-purple"> -Menu Utama-</b></center></li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-align-justify"></i> <span> Sistem Operasi | SAP.</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>home"><i class="fa fa-home text-red"></i> Home </a></li>
            <li><a href="<?php echo base_url(); ?>home/#anggota"><i class="fa fa-user text-aqua"></i> Anggota Kelompok </a></li>
            <li><a href="<?php echo base_url(); ?>home/aboutprogram"><i class="fa fa-code text-navy"></i> Tentang Program </a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa  fa-slack"></i> <span > Metode Algoritma</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>metode/fcfs"><i class="fa  fa-chevron-circle-right  text-red"></i> FCFS </a></li>
            <li><a href="<?php echo base_url(); ?>metode/sjf"><i class="fa  fa-chevron-circle-right  text-green"></i> SFJ </a></li>
            <li><a href="<?php echo base_url(); ?>metode/sjfnp"><i class="fa  fa-chevron-circle-right  text-blue"></i> SFJ-NP</a></li>
             <li><a href="<?php echo base_url(); ?>metode/priority"><i class="fa  fa-chevron-circle-right  text-lime"></i> PRIORITY</a></li>
              <li><a href="<?php echo base_url(); ?>metode/prioritynp"><i class="fa  fa-chevron-circle-right  text-olive"></i> PRIORITY-NP</a></li>
               <li><a href="<?php echo base_url(); ?>metode/roundrobin"><i class="fa  fa-chevron-circle-right  text-light-blue"></i> ROUND ROBIN</a></li>
          </ul>
        </li>
        <li class="treeview">
          <a href="#">
            <i class="fa fa-book"></i> <span>Documentations</span>
            <span class="pull-right-container">
              <i class="fa fa-angle-left pull-right"></i>
            </span>
          </a>
          <ul class="treeview-menu">
            <li><a href="<?php echo base_url(); ?>home"><i class="fa fa-github text-red"></i> Code On Github </a></li>
          </ul>
        </li>
        
    </section>

  </aside>

  <div class="content-wrapper">
    <section class="content-header">
        <small>* Beta Version (Non Database) </small>
      </h1>
      <ol class="breadcrumb">

        <li><a href="#"><i class="fa fa-slack"></i> Home</a></li>
      </ol>
    </section>
  <section class="content">

      <div class="row">
        <div class="col-md-12">
          <ul class="timeline">

            <li class="time-label">
                  <span class="bg-purple">
                    Selamat Datang Di SAP (Simulasi Algoritma Penjadwalan)
                  </span>
            </li>

            <li>
              <i class="fa fa-chevron-right bg-blue"></i>

              <div class="timeline-item">
                
                <h3 class="timeline-header"><a href="#"><i class="fa fa-slack "></i> | Introduction</a></h3>

                <div class="timeline-body">
                    <p><b>Sebuah sistem operasi (OS)</b> adalah kumpulan perangkat lunak yang mengelola sumber daya perangkat keras komputer dan menyediakan layanan umum untuk program komputer.
                    Sistem operasi adalah komponen penting dari perangkat lunak dalam sistem komputer, Sistem Operasi pada saat ini telah berkembang sangat pesat, banyak Pengembang 
                    Sistem Operasi Baik Itu Bersifat Open Source Maupu Memiliki lisesnsi,Di Balik Semua Itu Sebenarnya Terdapat Suatu Proses Baik Di Depan Layar Maupun Di Belakang Layar Salah Satunya Algoritma Penjadwalan 
                    
                    <br><br>
                    </p>
                </div>
              </div>
            </li>

            <li>
              <i class="fa fa-code bg-purple" id=="#aboutprogram"></i>

              <div class="timeline-item">
                <span class="time"><i class="fa fa-clock-o"></i> 27 mins ago</span>

                <h3 class="timeline-header"><a href="#">Tentang Program</a></h3>

                <div class="timeline-body">
                  <br>
                  SAP (Simulasi Algoritma Penjadwalan) Adalah Sebuah Program Yang Dirancang Untuk Memudahkan Suatu Proses Penghitungan Atau Algoritma Yang Terjadi Saat Penjadwalan
                  Dalam Sebuah CPU,Selain Itu Program Ini Pun Sebagai Syarat Agar Bisa Lulus Dalam Mata Kuliah Sistem Operasi <br><br>
                  
                  <b>Framework PHP Yang Digunakan  : </b><i>CodeIgniter 3.1.4</i><br>
                  <b>Framework CSS Yang Digunakan  : </b><i>Bootsrap 3.3.6 Admin LTE</i><br>
                  Starte Project                : 17 Juni 2017<br>
                  Finaled Project               : ? <br>
                </div>
                <div class="timeline-footer">
                  <a class="btn btn-warning btn-flat btn-xs">View comment</a>
                </div>
              </div>
            </li>
            
              <li>
              <i class="fa fa-hand-paper-o bg-aqua"></i>

              <div class="timeline-item">
                 <h3 class="timeline-header"><a href="#"></i>Tata Cara Penggunaa Aplikasi </a></h3>
                 <div class="timeline-body">
                    <b>1.</b>Gunakan Pin Code 1234 Untuk Melakukan Autentikasi<br>
                    <b>2.</b>Home-><i class="fa  fa-slack"></i>  Metode Algoritma
                </div>
                 
              </div>
            </li>
            <li class="time-label">
                  <span class="bg-purple">
                    Anggota Kelompok
                  </span>
            </li>

            <li>
              <i class="fa fa-group bg-maroon"></i>
              
              <div class="timeline-item" id="anggota">
                  <div class="col-md-3">
               <div class="box box-warning">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>dist/img/akbar.PNG" alt="User profile picture">

              <h3 class="profile-username text-center">Akbar Nurrahim</h3>

              <p class="text-muted text-center">Software Engineer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nrp  </b> <a class="pull-right">161014030</a>
                </li>
                <li class="list-group-item">
                  <b>No Absen</b> <a class="pull-right">02</a>
                </li>
                <li class="list-group-item">
                  <b>Kelas </b> <a class="pull-right">1IF-02</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
              </div>
              </div>
               <div class="col-md-3">
               <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>dist/img/ozan.PNG" alt="User profile picture">

              <h3 class="profile-username text-center">Fauzan Asy'ari</h3>

              <p class="text-muted text-center">Software Engineer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nrp  </b> <a class="pull-right">160613055</a>
                </li>
                <li class="list-group-item">
                  <b>No Absen</b> <a class="pull-right">02</a>
                </li>
                <li class="list-group-item">
                  <b>Kelas </b> <a class="pull-right">1IF-02</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
              </div>
              </div>
                  
                   <div class="col-md-3">
               <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>dist/img/rian.PNG" alt="User profile picture">

              <h3 class="profile-username text-center">Rian Ramadhan</h3>

              <p class="text-muted text-center">Software Engineer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nrp  </b> <a class="pull-right">160613053</a>
                </li>
                <li class="list-group-item">
                  <b>No Absen</b> <a class="pull-right">02</a>
                </li>
                <li class="list-group-item">
                  <b>Kelas </b> <a class="pull-right">1IF-02</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
              </div>
              </div>
                  
                   <div class="col-md-3">
               <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>dist/img/gilang.PNG" alt="User profile picture">

              <h3 class="profile-username text-center">Muhammad Gilang Ramadhan</h3>

              <p class="text-muted text-center">Software Engineer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nrp  </b> <a class="pull-right">160613044</a>
                </li>
                <li class="list-group-item">
                  <b>No Absen</b> <a class="pull-right">02</a>
                </li>
                <li class="list-group-item">
                  <b>Kelas </b> <a class="pull-right">1IF-02</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
              </div>
              </div>
                  
                <div class="col-md-3">
               <div class="box box-primary">
            <div class="box-body box-profile">
              <img class="profile-user-img img-responsive img-circle" src="<?php echo base_url(); ?>dist/img/idang.PNG" alt="User profile picture">

              <h3 class="profile-username text-center">Maulana Sidang</h3>

              <p class="text-muted text-center">Software Engineer</p>

              <ul class="list-group list-group-unbordered">
                <li class="list-group-item">
                  <b>Nrp  </b> <a class="pull-right">161014015</a>
                </li>
                <li class="list-group-item">
                  <b>No Absen</b> <a class="pull-right">02</a>
                </li>
                <li class="list-group-item">
                  <b>Kelas </b> <a class="pull-right">1IF-02</a>
                </li>
              </ul>

              <a href="#" class="btn btn-primary btn-block"><b>Follow</b></a>
            </div>
              </div>
              </div>
              </div>
            </li>
            <li>
              <i class="fa fa-clock-o bg-gray"></i>
            </li>
          </ul>
        </div>
      </div>

     

    </section>
  </div>

  <footer class="main-footer">
    <div class="pull-right hidden-xs text-purple" >
      Page rendered in <strong>{elapsed_time}</strong> Second.
    </div>
  </footer>

  <div class="control-sidebar-bg"></div>
</div>
<script src="<?php echo base_url(); ?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo base_url(); ?>/bootstrap/js/bootstrap.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/slimScroll/jquery.slimscroll.min.js"></script>
<script src="<?php echo base_url(); ?>/plugins/fastclick/fastclick.js"></script>
<script src="<?php echo base_url(); ?>/dist/js/app.min.js"></script>
<script src="<?php echo base_url(); ?>/dist/js/demo.js"></script>
</body>
</html>
