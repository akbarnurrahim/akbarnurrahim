<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>SAP | Algoritma Penjadwalan </title>
  <meta content="width=device-width, initial-scale=1, maximum-scale=1, user-scalable=no" name="viewport">
  <link rel="stylesheet" href="<?php echo base_url();?>/bootstrap/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.5.0/css/font-awesome.min.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/ionicons/2.0.1/css/ionicons.min.css">
  <link rel="stylesheet" href="<?php echo base_url();?>/dist/css/AdminLTE.min.css">
</head>
<script type="text/javascript">
    function validasi()
    {
        if (!$("#pin").val() )
        {
            alert('Maaf Pin Tidak Boleh Kosong');
            $("#pin").focus();
            return false;
        }     
    }
</script>
<body class="hold-transition lockscreen">
<div class="lockscreen-wrapper">
   <div class="lockscreen-logo">
    <a href="<?php echo base_url();?> /login "><b>Login </b> | SAP.</a>
  </div>
  <div class="lockscreen-item">
    <div class="lockscreen-image">
      <img src="<?php echo base_url();?>/dist/img/user1-128x128.jpg" alt="User Image">
    </div>

    <form class="lockscreen-credentials" method="POST" action="<?php echo base_url(); ?>/index.php/login/getlogin" onsubmit="return validasi();">
      <div class="input-group">
        <input type="password" name="pin" id="pin" class="form-control" placeholder="insert pin">

        <div class="input-group-btn">
          <button type="submit" class="btn"><i class="fa fa-arrow-right text-muted"></i></button>
        </div>
      </div>
    </form>
  </div>
  <div class="help-block text-center">
  <?php
  $info = $this->session->flashdata('info');
  if (!empty($info))
  {
      echo $info;
  }
  ?>
  </div>
  <div class="text-center">

  </div>
  <?php
  for ($i=0; $i<=10; $i++)
  {
      echo "<br>";
  }
  ?>
  <div class="lockscreen-footer text-center">
    Masukan Pin <b>1234</b> Untuk Melakukan Login
    Copyright &copy; 2017-2018 <b><a href="http://almsaeedstudio.com" class="text-black">Kelompok 2 | 1IF-02</a></b><br>
    Page rendered in <strong>{elapsed_time}</strong> Second
  </div>
</div>
  </div>
</div>
<script src="<?php echo base_url();?>/plugins/jQuery/jquery-2.2.3.min.js"></script>
<script src="<?php echo base_url();?>/bootstrap/js/bootstrap.min.js"></script>
</body>
</html>
